<?php
$url = isset($_POST['url']) ? addslashes(trim($_POST['url'])) : '';
$type = isset($_POST['type']) ? addslashes(trim($_POST['type'])) : '';
$width = isset($_POST['width']) ? addslashes(trim($_POST['width'])) : '';
$logo = isset($_POST['logo']) ? addslashes(trim($_POST['logo'])) : '';
$foreground = isset($_POST['foreground']) ? addslashes(trim($_POST['foreground'])) : "";
$background = isset($_POST['background']) ? addslashes(trim($_POST['background'])) : "";
switch($type){
	case "default":
	case "custom":
	case "parse":
		$res=file_get_contents("https://www.tongleer.com/api/web/?action=qrcode&type=".$type."&url=".$url."&width=".$width."&logo=".$logo."&foreground=".@urlencode($foreground)."&background=".@urlencode($background));
		echo($res);
		break;
}
?>