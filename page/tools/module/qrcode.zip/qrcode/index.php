<?php
/**
 * @title 二维码扫描生成器
 * @subtitle 简约实用的二维码扫描生成工具
 * @package qrcode
 * @description 二维码扫描生成器是一款简单实用的扫描解析二维码以及生成二维码的小工具。
 * @author 二呆
 * @author email diamond@tongleer.com
 * @author qq 2293338477
 * @author info 一个好人
 * @link http://www.tongleer.com
 * @version 1.0.1
 * @picture https://ws3.sinaimg.cn/large/ecabade5ly1fy7n4evhfmj20sg0sgaa6.jpg
*/
?>
<html>
<head>
	<meta charset="UTF-8">
	<title>二维码扫描生成器 - 简约实用的二维码扫描生成工具</title>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
	<meta name="format-detection" content="telephone=no">
	<meta name="renderer" content="webkit">
	<meta http-equiv="Cache-Control" content="no-siteapp"/>
	<meta name="author" content="二呆">
	<meta name="keywords" content="二维码,二维码制作,二维码扫描,QR code,二维码生成,二维码扫描生成器" />
	<meta name="description" content="二维码扫描生成器是一款简单实用的扫描解析二维码以及生成二维码的小工具。" />
	<meta property="og:image" content="https://ws3.sinaimg.cn/large/ecabade5ly1fy7o6kdreij208c08c75b.jpg"/>
	<link rel="stylesheet" href="//cdnjs.loli.net/ajax/libs/mdui/0.4.2/css/mdui.min.css">
	<link rel="alternate icon" href="https://ws3.sinaimg.cn/large/ecabade5ly1fxtqvq1t0lj200s00s744.jpg" type="image/png" />
	<script src="https://libs.baidu.com/jquery/1.11.1/jquery.min.js"></script>
</head>
<body class="mdui-theme-primary-indigo mdui-theme-accent-pink">
	
	<div class="mdui-panel" mdui-panel>
	  <div class="mdui-panel-item mdui-panel-item-open">
		<div class="mdui-panel-item-header">二维码生成</div>
		<div class="mdui-panel-item-body">
			<form id="qrcodeForm" method="get" action="">
				<div class="mdui-textfield">
				  <input class="mdui-textfield-input" type="text" id="url" placeholder="需要输入内容或者链接" />
				  <div class="mdui-textfield-helper">根据以下类型输入适当的内容开始制作二维码。</div>
				</div>
				<label class="mdui-radio">
					<input type="radio" name="type" id="default" value="default" checked/><i class="mdui-radio-icon"></i>生成默认二维码
				</label>
				<label class="mdui-radio">
					<input type="radio" name="type" id="custom" value="custom"/><i class="mdui-radio-icon"></i>生成自定义二维码
				</label>
				<label class="mdui-radio">
					<input type="radio" name="type" id="parse" value="parse"/><i class="mdui-radio-icon"></i>二维码内容扫描解析
				</label>
				<div class="mdui-textfield">
				  <input class="mdui-textfield-input" type="text" id="width" placeholder="边长，默认为200" />
				  <div class="mdui-textfield-helper">自定义二维码的边长</div>
				</div>
				<div class="mdui-textfield">
				  <input class="mdui-textfield-input" type="text" id="foreground" placeholder="前景色，默认为黑色" />
				  <div class="mdui-textfield-helper">自定义二维码的前景色</div>
				</div>
				<div class="mdui-textfield">
				  <input class="mdui-textfield-input" type="text" id="background" placeholder="背景色，默认为白色" />
				  <div class="mdui-textfield-helper">自定义二维码的背景色</div>
				</div>
				<div class="mdui-textfield">
				  <input class="mdui-textfield-input" type="text" id="logo" placeholder="Logo图标，默认为空" />
				  <div class="mdui-textfield-helper">自定义二维码的Logo</div>
				</div>
				<button class="mdui-btn mdui-btn-raised mdui-ripple mdui-color-theme-accent">生成</button>
				<div id="result"></div>
			</form>
		</div>
	  </div>
	</div>
	
	<div class="mdui-panel" mdui-panel>
	  <div class="mdui-panel-item mdui-panel-item-open">
		<div class="mdui-panel-item-header">二维码扫描生成器工具简介</div>
		<div class="mdui-panel-item-body">
		  <p>*二维码扫描生成器是一款简单实用的扫描解析二维码以及生成二维码的小工具。</p>
		  <p>*使用二维码接口生成二维码</p>
		  <p>*支持二维码解析,只需一个图片地址即可解析</p>
		</div>
	  </div>
	</div>
	<script>
		$(function(){
			$("#qrcodeForm").submit(function(){
				if($("#url").val()==""){
					alert("需要输入内容或者链接");
					return false;
				}
				switch($("input:radio[name='type']:checked").val()){
					case "default":
					case "custom":
					case "parse":
						var progress = layer.load();
						$.ajax({
							type : "POST",
							url : "<?=TOOLURL;?>ajax.php",
							data : {"url":$("#url").val(),"width":$("#width").val(),"logo":$("#logo").val(),"foreground":$("#foreground").val(),"background":$("#background").val(),"type":$("input:radio[name='type']:checked").val()},
							dataType : 'text',
							success : function(data) {
								layer.close(progress);
								layer.confirm('<center>'+data+'</center>', {
									btn: ['关闭'],
									title:"生成结果"
								},function(index){
									layer.close(index);
								});
							},error:function(data){
							}
						});
						break;
				}
				return false;
			});
		});
	</script>
	<script src="//cdnjs.loli.net/ajax/libs/mdui/0.4.2/js/mdui.min.js"></script>
	<script src="https://cdn.bootcss.com/layer/3.1.0/layer.js"></script>
	<?php include TOOLINCLUDE."footer.php";?>
</body>
</html>