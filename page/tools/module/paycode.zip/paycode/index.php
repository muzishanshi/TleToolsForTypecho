<?php
/**
 * @title 三合一收款码
 * @subtitle 快速制作三大支付收款码
 * @package paycode
 * @description 快速制作支持微信、QQ、支付宝支付二维码的收款二维码。
 * @author 二呆
 * @author email diamond@tongleer.com
 * @author qq 2293338477
 * @author info 一个好人
 * @link http://www.tongleer.com
 * @version 1.0.1
 * @picture https://ws3.sinaimg.cn/large/005V7SQ5ly1fyjk2qsk5hj305k05k743.jpg
*/
?>
<html>
<head>
	<meta charset="UTF-8">
	<title>三合一收款码 - 快速制作三大支付收款码</title>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
	<meta name="format-detection" content="telephone=no">
	<meta name="renderer" content="webkit">
	<meta http-equiv="Cache-Control" content="no-siteapp"/>
	<meta name="author" content="二呆">
	<meta name="keywords" content="三合一收款码制作,收款码制作,三合一收款码,收款码生成器" />
	<meta name="description" content="三合一收款码制作为每一位个人商家提供便捷的微信、QQ、支付宝支付收款二维码制作方案。" />
	<meta property="og:image" content="https://ws3.sinaimg.cn/large/ecabade5ly1fy7o6kdreij208c08c75b.jpg"/>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/amazeui/2.7.2/css/amazeui.min.css">
	<link rel="alternate icon" href="https://ws3.sinaimg.cn/large/ecabade5ly1fxtqvq1t0lj200s00s744.jpg" type="image/png" />
	<script src="https://libs.baidu.com/jquery/1.11.1/jquery.min.js"></script>
</head>
<body>
	<div class="am-panel-group">
	  <div class="am-panel am-panel-default">
		<div class="am-panel-hd">
		  <h4 class="am-panel-title">
			三合一收款码制作
		  </h4>
		</div>
		<div class="am-panel-collapse am-collapse am-in">
		  <div class="am-panel-bd">
			<div class="am-u-lg-6 am-u-md-8 am-u-sm-centered">
				<form class="am-form" id="paycodeForm" method="get" action="">
					<div class="am-form-group am-g-collapse">
						<div class="am-u-sm-8">
							<input type="text" name="alipayurl" id="alipayurl" placeholder="支付宝收款链接">
						</div>
						<div class="am-form-group am-form-file">
							<button type="button" class="am-btn am-btn-danger am-btn-sm"><i class="am-icon-cloud-upload"></i> 选择支付宝收款码</button>
							<input id="alipayfile" type="file" accept="image/*">
						</div>
					</div>
					<div class="am-form-group am-g-collapse">
						<div class="am-u-sm-8">
							<input type="text" name="wxpayurl" id="wxpayurl" value="" placeholder="微信收款链接">
						</div>
						<div class="am-form-group am-form-file">
							<button type="button" class="am-btn am-btn-danger am-btn-sm"><i class="am-icon-cloud-upload"></i> 选择 微 信 收款码</button>
							<input id="wxpayfile" type="file" accept="image/*">
						</div>
					</div>
					<div class="am-form-group am-g-collapse">
						<div class="am-u-sm-8">
							<input type="text" name="qqpayurl" id="qqpayurl" value="" placeholder="手机QQ收款链接">
						</div>
						<div class="am-form-group am-form-file">
							<button type="button" class="am-btn am-btn-danger am-btn-sm"><i class="am-icon-cloud-upload"></i> 选择 Ｑ Ｑ 收款码</button>
							<input id="qqpayfile" type="file" accept="image/*">
						</div>
					</div>				
					<br>
					<div class="am-cf">
						<input type="hidden" id="TOOLINCLUDE" value="<?=TOOLINCLUDE;?>" />
						<input type="hidden" id="TOOLURL" value="<?=TOOLURL;?>" />
						<input type="submit" value="立即生成" class="am-btn am-btn-primary am-btn-sm am-fl">
					</div>
				</form>
				<img id="qrcode" class="am-center am-img-thumbnail am-img-responsive" style="width: 206px;display: none;">
			</div>
		  </div>
		</div>
	  </div>
	  <div class="am-panel am-panel-default">
		<div class="am-panel-hd">
		  <h4 class="am-panel-title">
			三合一收款码工具简介
		  </h4>
		</div>
		<div class="am-panel-collapse am-collapse am-in">
		  <div class="am-panel-bd">
			<p>在线生成支持QQ、支付宝、微信三合一收款码的小工具</p>
			<p>保存三个平台的收款码即可，然后上传图片自动识别收款码地址</p>
			<p>点击生成之后就可以得到一张能识别三个平台收款码的图片</p>
			<p>最后保存图片即可使用</p>
		  </div>
		</div>
	  </div>
	</div>
	
	<script>
		$(function(){
			$("#alipayfile").change(function(){
				var file=new FormData();
				file.append('file',$("#alipayfile")[0].files[0]);
				file.append('action','alipay');
				file.append('TOOLINCLUDE',$("#TOOLINCLUDE").val());
				file.append('TOOLURL',$("#TOOLURL").val());
				var progress = layer.load();
				$.ajax({
					type : "POST",
					url : "<?=TOOLURL;?>ajax.php",
					data : file,
					dataType : 'text',
					processData: false,
					contentType: false,
					cache: false,
					success : function(data) {
						layer.close(progress);
						$("#alipayurl").val(data);
					},error:function(data){
					}
				});
			});
			$("#wxpayfile").change(function(){
				var file=new FormData();
				file.append('file',$("#wxpayfile")[0].files[0]);
				file.append('action','wxpay');
				file.append('TOOLINCLUDE',$("#TOOLINCLUDE").val());
				file.append('TOOLURL',$("#TOOLURL").val());
				var progress = layer.load();
				$.ajax({
					type : "POST",
					url : "<?=TOOLURL;?>ajax.php",
					data : file,
					dataType : 'text',
					processData: false,
					contentType: false,
					cache: false,
					success : function(data) {
						layer.close(progress);
						$("#wxpayurl").val(data);
					},error:function(data){
					}
				});
			});
			$("#qqpayfile").change(function(){
				var file=new FormData();
				file.append('file',$("#qqpayfile")[0].files[0]);
				file.append('action','qqpay');
				file.append('TOOLINCLUDE',$("#TOOLINCLUDE").val());
				file.append('TOOLURL',$("#TOOLURL").val());
				var progress = layer.load();
				$.ajax({
					type : "POST",
					url : "<?=TOOLURL;?>ajax.php",
					data : file,
					dataType : 'text',
					processData: false,
					contentType: false,
					cache: false,
					success : function(data) {
						layer.close(progress);
						$("#qqpayurl").val(data);
					},error:function(data){
					}
				});
			});
			$("#paycodeForm").submit(function(){
				var progress = layer.load();
				$.ajax({
					type : "POST",
					url : "<?=TOOLURL;?>ajax.php",
					data : {"action":"submit","wxpayurl":$("#wxpayurl").val(),"alipayurl":$("#alipayurl").val(),"qqpayurl":$("#qqpayurl").val(),"TOOLINCLUDE":$("#TOOLINCLUDE").val(),"TOOLURL":$("#TOOLURL").val()},
					dataType : 'json',
					success : function(data) {
						layer.close(progress);
						if(data.status=="success"){
							layer.confirm('<center><img src="'+data.result+'" width="300" /></center>', {
								btn: ['关闭'],
								title:"生成结果"
							},function(index){
								layer.close(index);
							});
						}
					},error:function(data){
					}
				});
				return false;
			});
		});
	</script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/amazeui/2.7.2/js/amazeui.min.js"></script>
	<script src="https://cdn.bootcss.com/layer/3.1.0/layer.js"></script>
	<?php include TOOLINCLUDE."footer.php";?>
</body>
</html>