<?php
$TOOLINCLUDE = isset($_POST['TOOLINCLUDE']) ? addslashes(trim($_POST['TOOLINCLUDE'])) : '';
include $TOOLINCLUDE.'../../../../../config.inc.php';
$TOOLURL = isset($_POST['TOOLURL']) ? addslashes(trim($_POST['TOOLURL'])) : '';

$action = isset($_POST['action']) ? addslashes(trim($_POST['action'])) : '';
$wxpayurl = isset($_POST['wxpayurl']) ? addslashes(trim($_POST['wxpayurl'])) : '';
$alipayurl = isset($_POST['alipayurl']) ? addslashes(trim($_POST['alipayurl'])) : '';
$qqpayurl = isset($_POST['qqpayurl']) ? addslashes(trim($_POST['qqpayurl'])) : '';
switch($action){
	case "submit":
		$res=file_get_contents("https://tongleer.com/api/web/?action=paycode&wxpayurl=".$wxpayurl."&alipayurl=".$alipayurl."&qqpayurl=".urlencode($qqpayurl));
		echo($res);
		break;
	case "alipay":
	case "wxpay":
	case "qqpay":
		$filename = iconv("utf-8", "gbk", @$_FILES['file']['name']);
		move_uploaded_file(@$_FILES['file']['tmp_name'], dirname(__FILE__).'/'.$filename);
		$ch = curl_init();
		$filePath = dirname(__FILE__).'/'.$filename;
		$data = array('file' => '@' . $filePath);
		if (class_exists('\CURLFile')) {
			$data['file'] = new \CURLFile(realpath($filePath));
		} else {
			if (defined('CURLOPT_SAFE_UPLOAD')) {
				curl_setopt($ch, CURLOPT_SAFE_UPLOAD, FALSE);
			}
		}
		curl_setopt($ch, CURLOPT_URL, 'https://tongleer.com/api/web/?action=weiboimg');
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		$json=curl_exec($ch);
		curl_close($ch);
		@unlink(dirname(__FILE__).'/'.$filename);
		$arr=json_decode($json,true);
		$res=file_get_contents("https://tongleer.com/api/web/?action=qrcode&type=parse&url=".$arr["url"]);
		echo($res);
		break;
}
?>