<?php
$action = isset($_POST['action']) ? addslashes(trim($_POST['action'])) : '';
if($action=="city"){
	$city = isset($_POST['city']) ? addslashes(trim($_POST['city'])) : '';
	$res=file_get_contents("https://tongleer.com/api/web/?action=weather&operation=query&city=".$city);
	echo($res);
}else if($action=="all"){
	$res=file_get_contents("https://tongleer.com/api/web/?action=weather&operation=city");
	echo $res;
}else if($action=="ip"){
	$res=file_get_contents("https://tongleer.com/api/web/?action=weather");
	echo $res;
}
?>