<?php
/**
 * @title 天气预报
 * @subtitle 天气早知道
 * @package weather
 * @description 查询当天及未来天气的基本情况，以及查询支持的城市列表。提供天气信息包括：当前时间、当前气温、当前湿度，天气情况、污染指数、风向、风速、日出日落时间以及未来十天天气状况等。
 * @author 二呆
 * @author email diamond@tongleer.com
 * @author qq 2293338477
 * @author info 一个好人
 * @link http://www.tongleer.com
 * @version 1.0.1
 * @picture https://ws3.sinaimg.cn/large/ecabade5ly1fy5gjqhzs0j2028028wea.jpg
*/
?>
<html>
<head>
	<meta charset="UTF-8">
	<title>天气预报 - 天气早知道</title>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
	<meta name="format-detection" content="telephone=no">
	<meta name="renderer" content="webkit">
	<meta http-equiv="Cache-Control" content="no-siteapp"/>
	<meta name="author" content="二呆">
	<link rel="stylesheet" href="//cdnjs.loli.net/ajax/libs/mdui/0.4.2/css/mdui.min.css">
	<link rel="alternate icon" href="https://ws3.sinaimg.cn/large/ecabade5ly1fxtqvq1t0lj200s00s744.jpg" type="image/png" />
	<script src="https://libs.baidu.com/jquery/1.11.1/jquery.min.js"></script>
</head>
<body class="mdui-theme-primary-indigo mdui-theme-accent-pink">
	<div class="mdui-row-xs-3 mdui-row-sm-4 mdui-row-md-5 mdui-row-lg-6 mdui-row-xl-7 mdui-grid-list">
		<center id="weather"></center>
		<div class="mdui-dialog" id="dialog">
			<div class="mdui-dialog-content">
				<div class="mdui-dialog-title">天气预报</div>
				<div id="content" style="height:500px;" class="mdui-spinner mdui-spinner-colorful"></div>
			</div>
			<div class="mdui-dialog-actions">
				<button class="mdui-btn mdui-ripple" mdui-dialog-cancel>知道了</button>
			</div>
		</div>
	</div>
	<div style="margin:0 auto; width:150px; height:1px;" id="footer"></div>
	<?php include TOOLINCLUDE."footer.php";?>
	<script>
		$(function(){
			$.post("<?=TOOLURL;?>ajax.php",{"action":"ip"},function(data){
				$("#footer").html(data);
			});
			$.ajax({
				type : "POST",
				url : "<?=TOOLURL;?>ajax.php",
				data : {"action":"all"},
				dataType : 'json',
				success : function(data) {
					var key=0;
					for(var i=0;i<data.result.length;i++){
						for(var j=0;j<data.result[i].city.length;j++){
							var div='<div class="mdui-col"><div class="mdui-grid-tile"><a id="query'+key+'" data-city="'+data.result[i].city[j].city+'" class="query" href="javascript:;">'+data.result[i].city[j].city+'</a></div></div>';
							$("#weather").append(div);
							key++;
						}
					}
					var dialog = new mdui.Dialog("#dialog");
					$(".query").each(function(){
						var id=$(this).attr("id");
						$("#"+id).click( function () {
							dialog.open();
							$.post("<?=TOOLURL;?>ajax.php",{"action":"city",city:$(this).attr('data-city')},function(data){
								$("#content").removeClass("mdui-spinner");
								var data=JSON.parse(data);
								var res=data.result[0];
								$("#content").html('<div class="mdui-table-fluid"><table class="mdui-table"><tbody><tr><td>空气质量</td><td>'+res.airCondition+'</td></tr><tr><td>城市</td><td>'+res.city+'</td></tr><tr><td>寒潮</td><td>'+res.coldIndex+'</td></tr><tr><td>更新时间</td><td>'+res.date+'</td></tr><tr><td>分布</td><td>'+res.distrct+'</td></tr><tr><td>穿着</td><td>'+res.dressingIndex+'</td></tr><tr><td>运动</td><td>'+res.exerciseIndex+'</td></tr><tr><td>未来预报</td><td><table class="mdui-table"><tbody><tr><td>'+res.future[0].week+'</td></tr><tr><td>'+res.future[0].date+'</td></tr><tr><td>'+res.future[0].night+'</td></tr><tr><td>'+res.future[0].temperature+'</td></tr><tr><td>'+res.future[0].wind+'</td></tr><tr><td>&nbsp;</td></tr><tr><td>'+res.future[1].week+'</td></tr><tr><td>'+res.future[1].date+'</td></tr><tr><td>'+res.future[1].night+'</td></tr><tr><td>'+res.future[1].temperature+'</td></tr><tr><td>'+res.future[1].wind+'</td></tr><tr><td>&nbsp;</td></tr><tr><td>'+res.future[2].week+'</td></tr><tr><td>'+res.future[2].date+'</td></tr><tr><td>'+res.future[2].night+'</td></tr><tr><td>'+res.future[2].temperature+'</td></tr><tr><td>'+res.future[2].wind+'</td></tr><tr><td>&nbsp;</td></tr><tr><td>'+res.future[3].week+'</td></tr><tr><td>'+res.future[3].date+'</td></tr><tr><td>'+res.future[3].night+'</td></tr><tr><td>'+res.future[3].temperature+'</td></tr><tr><td>'+res.future[3].wind+'</td></tr><tr><td>&nbsp;</td></tr><tr><td>'+res.future[4].week+'</td></tr><tr><td>'+res.future[4].date+'</td></tr><tr><td>'+res.future[4].night+'</td></tr><tr><td>'+res.future[4].temperature+'</td></tr><tr><td>'+res.future[4].wind+'</td></tr><tr><td>&nbsp;</td></tr><tr><td>'+res.future[5].week+'</td></tr><tr><td>'+res.future[5].date+'</td></tr><tr><td>'+res.future[5].night+'</td></tr><tr><td>'+res.future[5].temperature+'</td></tr><tr><td>'+res.future[5].wind+'</td></tr><tr><td>&nbsp;</td></tr></tbody></table></td></tr><tr><td>潮湿</td><td>'+res.humidity+'</td></tr><tr><td>省份</td><td>'+res.province+'</td></tr><tr><td>日落</td><td>'+res.sunset+'</td></tr><tr><td>日出</td><td>'+res.sunrise+'</td></tr><tr><td>温度</td><td>'+res.temperature+'</td></tr><tr><td>发布时间</td><td>'+res.time+'</td></tr><tr><td>洗澡</td><td>'+res.washIndex+'</td></tr><tr><td>天气</td><td>'+res.weather+'</td></tr><tr><td>星期</td><td>'+res.week+'</td></tr><tr><td>风力</td><td>'+res.wind+'</td></tr></tbody></table></div>');
								
							});
						});
					});
				},error:function(data){
					alert("获取数据错误");
				}
			});
		});
	</script>
	<script src="//cdnjs.loli.net/ajax/libs/mdui/0.4.2/js/mdui.min.js"></script>
</body>
</html>