<?php
$action = isset($_POST['action']) ? addslashes(trim($_POST['action'])) : '';
if($action=="icp"){
	$domain = isset($_POST['domain']) ? addslashes(trim($_POST['domain'])) : '';
	$res=file_get_contents("https://tongleer.com/api/web/?action=icp&domain=".$domain);
	echo($res);
}else if($action=="siteweight"){
	$domain = isset($_POST['domain']) ? addslashes(trim($_POST['domain'])) : '';
	$res=file_get_contents("https://tongleer.com/api/web/?action=siteweight&domain=".$domain);
	echo($res);
}
?>