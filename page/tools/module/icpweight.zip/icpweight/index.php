<?php
/**
 * @title 网站备案权重查询
 * @subtitle 备案权重一起查才方便
 * @package icpweight
 * @description 基于爱站的网站备案及权重查询方式。
 * @author 二呆
 * @author email diamond@tongleer.com
 * @author qq 2293338477
 * @author info 一个好人
 * @link http://www.tongleer.com
 * @version 1.0.1
 * @picture https://ws3.sinaimg.cn/large/ecabade5ly1fy7e95qm8hj202i02ijrc.jpg
*/
?>
<html>
<head>
	<meta charset="UTF-8">
	<title>网站备案权重查询 - 备案权重一起查才方便</title>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
	<meta name="format-detection" content="telephone=no">
	<meta name="renderer" content="webkit">
	<meta http-equiv="Cache-Control" content="no-siteapp"/>
	<meta name="author" content="二呆">
	<link rel="stylesheet" href="//cdnjs.loli.net/ajax/libs/mdui/0.4.2/css/mdui.min.css">
	<link rel="alternate icon" href="https://ws3.sinaimg.cn/large/ecabade5ly1fxtqvq1t0lj200s00s744.jpg" type="image/png" />
	<script src="https://libs.baidu.com/jquery/1.11.1/jquery.min.js"></script>
</head>
<body class="mdui-theme-primary-indigo mdui-theme-accent-pink">
	<form id="domainForm" method="get" action="">
		<div class="mdui-textfield">
		  <i class="mdui-icon material-icons">&#xe32a;</i>
		  <label class="mdui-textfield-label">网站域名</label>
		  <input class="mdui-textfield-input" type="text" id="domain"/>
		  <div class="mdui-textfield-helper">输入域名，基于爱站查询网站备案及权重信息。</div>
		</div>
	</form>
	<div id="querydomainresult" style="display:none;" class="mdui-table-fluid">
	  <table class="mdui-table">
		<tbody>
		  <tr><td>主办单位名称</td><td id="unitname"></td></tr>
		  <tr><td>主办单位性质</td><td id="unittype"></td></tr>
		  <tr><td>网站备案/许可证号</td><td id="icp"></td></tr>
		  <tr><td>网站名称</td><td id="sitename"></td></tr>
		  <tr><td>网站首页网址</td><td id="siteurl"></td></tr>
		  <tr><td>网站域名</td><td id="sitedomain"></td></tr>
		  <tr><td>审核时间</td><td id="time"></td></tr>
		  <tr><td>网站权重</td><td id="aizhanimg"></td></tr>
		</tbody>
	  </table>
	</div>
	<script>
		$(function(){
			$("#domainForm").submit(function(){
				if($("#domain").val()==""){
					alert("需要输入网站域名");
					return false;
				}
				$.ajax({
					type : "POST",
					url : "<?=TOOLURL;?>ajax.php",
					data : {"action":"icp","domain":$("#domain").val()},
					dataType : 'json',
					success : function(data) {
						if(data.error!=-1){
							$("#unitname").html(data.unitname);
							$("#unittype").html(data.unittype);
							$("#icp").html(data.icp);
							$("#sitename").html(data.sitename);
							$("#siteurl").html(data.siteurl);
							$("#sitedomain").html(data.domain);
							$("#time").html(data.time);
							$("#querydomainresult").css("display","block");
						}else{
							alert("暂无查到备案信息");
						}
					},error:function(data){
						
					}
				});
				$.ajax({
					type : "POST",
					url : "<?=TOOLURL;?>ajax.php",
					data : {"action":"siteweight","domain":$("#domain").val()},
					dataType : 'json',
					success : function(data) {
						if(data.error!=-1){
							$("#aizhanimg").html(data.aizhanimg);
							$("#querydomainresult").css("display","block");
						}else{
							alert("暂无查到备案信息");
						}
					},error:function(data){
						
					}
				});
				return false;
			});
		});
	</script>
	<script src="//cdnjs.loli.net/ajax/libs/mdui/0.4.2/js/mdui.min.js"></script>
	
	<?php include TOOLINCLUDE."footer.php";?>
</body>
</html>