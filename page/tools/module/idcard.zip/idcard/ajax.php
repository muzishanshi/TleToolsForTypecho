<?php
$action = isset($_POST['action']) ? addslashes(trim($_POST['action'])) : '';
if($action=="idcard"){
	$cardno = isset($_POST['cardno']) ? addslashes(trim($_POST['cardno'])) : '';
	$res=file_get_contents("https://tongleer.com/api/web/?action=idcard&cardno=".$cardno);
	echo($res);
}
?>