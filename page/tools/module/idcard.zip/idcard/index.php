<?php
/**
 * @title 身份证查询
 * @subtitle 简单的身份证查询工具
 * @package idcard
 * @description 查询身份证的基本信息，并非身份证鉴别。
 * @author 二呆
 * @author email diamond@tongleer.com
 * @author qq 2293338477
 * @author info 一个好人
 * @link http://www.tongleer.com
 * @version 1.0.1
 * @picture https://ws3.sinaimg.cn/large/ecabade5ly1fy77lgbzpwj2028028q2q.jpg
*/
?>
<html>
<head>
	<meta charset="UTF-8">
	<title>身份证查询 - 简单的身份证查询工具</title>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
	<meta name="format-detection" content="telephone=no">
	<meta name="renderer" content="webkit">
	<meta http-equiv="Cache-Control" content="no-siteapp"/>
	<meta name="author" content="二呆">
	<link rel="stylesheet" href="//cdnjs.loli.net/ajax/libs/mdui/0.4.2/css/mdui.min.css">
	<link rel="alternate icon" href="https://ws3.sinaimg.cn/large/ecabade5ly1fxtqvq1t0lj200s00s744.jpg" type="image/png" />
	<script src="https://libs.baidu.com/jquery/1.11.1/jquery.min.js"></script>
</head>
<body class="mdui-theme-primary-indigo mdui-theme-accent-pink">
	<form id="cardnoForm" method="get" action="">
		<div class="mdui-textfield">
		  <i class="mdui-icon material-icons">&#xe06e;</i>
		  <label class="mdui-textfield-label">身份证号码</label>
		  <input class="mdui-textfield-input" type="text" id="cardno"/>
		  <div class="mdui-textfield-helper">输入身份证号码，查询基本信息。</div>
		</div>
	</form>
	<div id="querycardnoresult" style="display:none;" class="mdui-table-fluid">
	  <table class="mdui-table">
		<thead>
		  <tr>
			<th>地区</th>
			<th>生日</th>
			<th>性别</th>
		  </tr>
		</thead>
		<tbody>
		  <tr>
			<td id="area"></td>
			<td id="birthday"></td>
			<td id="sex"></td>
		  </tr>
		</tbody>
	  </table>
	</div>
	<script>
		$(function(){
			$("#cardnoForm").submit(function(){
				if($("#cardno").val()==""){
					alert("需要输入身份证号码");
					return false;
				}
				$.ajax({
					type : "POST",
					url : "<?=TOOLURL;?>ajax.php",
					data : {"action":"idcard","cardno":$("#cardno").val()},
					dataType : 'json',
					success : function(data) {
						if(data.msg=="success"){
							$("#area").html(data.result.area);
							$("#birthday").html(data.result.birthday);
							$("#sex").html(data.result.sex);
							$("#querycardnoresult").css("display","block");
						}else{
							alert("查询失败");
						}
					},error:function(data){
						alert("获取数据错误");
					}
				});
				return false;
			});
		});
	</script>
	<script src="//cdnjs.loli.net/ajax/libs/mdui/0.4.2/js/mdui.min.js"></script>
	
	<?php include TOOLINCLUDE."footer.php";?>
</body>
</html>