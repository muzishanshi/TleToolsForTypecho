<?php
/**
 * @title 邮编查询
 * @subtitle 邮编轻松查
 * @package postcode
 * @description 邮编查地名，地名查邮编，随心所欲。
 * @author 二呆
 * @author email diamond@tongleer.com
 * @author qq 2293338477
 * @author info 一个好人
 * @link http://www.tongleer.com
 * @version 1.0.1
 * @picture https://ws3.sinaimg.cn/large/ecabade5ly1fy6a9kg87wj2028028mwz.jpg
*/
?>
<html>
<head>
	<meta charset="UTF-8">
	<title>邮编查询 - 邮编轻松查</title>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
	<meta name="format-detection" content="telephone=no">
	<meta name="renderer" content="webkit">
	<meta http-equiv="Cache-Control" content="no-siteapp"/>
	<meta name="author" content="二呆">
	<link rel="stylesheet" href="//cdnjs.loli.net/ajax/libs/mdui/0.4.2/css/mdui.min.css">
	<link rel="alternate icon" href="https://ws3.sinaimg.cn/large/ecabade5ly1fxtqvq1t0lj200s00s744.jpg" type="image/png" />
	<script src="https://libs.baidu.com/jquery/1.11.1/jquery.min.js"></script>
</head>
<body class="mdui-theme-primary-indigo mdui-theme-accent-pink">
	<div class="mdui-tab mdui-tab-centered" mdui-tab>
		<a href="#querycode" class="mdui-ripple">查询邮编</a>
		<a href="#queryaddress" class="mdui-ripple">查询地名</a>
	</div>
	<div id="querycode" class="mdui-p-a-2">
		<form id="postcodeForm" method="get" action="">
			<div class="mdui-textfield">
			  <i class="mdui-icon material-icons">&#xe0d0;</i>
			  <label class="mdui-textfield-label">邮编</label>
			  <input class="mdui-textfield-input" type="number" id="postcode"/>
			  <div class="mdui-textfield-helper">输入邮编，查询地名。</div>
			</div>
		</form>
		<div id="querypostcoderesult" style="display:none;" class="mdui-table-fluid">
		  <table class="mdui-table">
			<thead>
			  <tr>
				<th>地名</th>
				<th>城市</th>
				<th>区域</th>
				<th>邮编</th>
				<th>省份</th>
			  </tr>
			</thead>
			<tbody>
			  <tr>
				<td id="address"></td>
				<td id="city"></td>
				<td id="district"></td>
				<td id="postNumber"></td>
				<td id="province"></td>
			  </tr>
			</tbody>
		  </table>
		</div>
	</div>
	<div id="queryaddress" class="mdui-p-a-2">
		<form id="addressForm" method="get" action="">
			<select id="selectprovince" class="mdui-select">
			  <option value="">省份</option>
			</select>
			<select id="selectcity" class="mdui-select">
			  <option value="">城市</option>
			</select>
			<button class="mdui-btn mdui-btn-raised mdui-ripple mdui-color-theme-accent">查询</button>
		</form>
		<div id="queryaddressresult" style="display:none;" class="mdui-table-fluid">
		  <table class="mdui-table">
			<thead>
			  <tr>
				<th>邮编</th>
				<th>地名</th>
				<th>城市</th>
				<th>区域</th>
				<th>省份</th>
			  </tr>
			</thead>
			<tbody id="queryaddressdata">
			</tbody>
		  </table>
		</div>
	</div>
	<?php include TOOLINCLUDE."footer.php";?>
	<script>
		$(function(){
			$("#addressForm").submit(function(){
				if($("#selectprovince").val()==""||$("#selectcity").val()==""){
					alert("选择省市后再进行查询");
					return false;
				}
				$.ajax({
					type : "POST",
					url : "<?=TOOLURL;?>ajax.php",
					data : {"action":"postcode","operation":"querycode","pid":$("#selectprovince").val(),"cid":$("#selectcity").val()},
					dataType : 'json',
					success : function(data) {
						if(data.msg=="success"){
							$("#queryaddressdata").empty();
							$("#queryaddressresult").css("display","block");
							for(var i=0;i<data.result.length;i++){
								$("#queryaddressdata").append('<tr><td>'+data.result[i].postNumber+'</td><td>'+data.result[i].address.join('，')+'</td><td>'+data.result[i].city+'</td><td>'+data.result[i].district+'</td><td>'+data.result[i].province+'</td></tr>');
							}
						}else{
							
						}
					},error:function(data){
						
					}
				});
				return false;
			});
			$.ajax({
				type : "POST",
				url : "<?=TOOLURL;?>ajax.php",
				data : {"action":"postcode","operation":"querycity"},
				dataType : 'json',
				success : function(data) {
					if(data.msg=="success"){
						var province='';
						for(var i=0;i<data.result.length;i++){
							province+='<option value="'+data.result[i].id+'">'+data.result[i].province+'</option>';
						}
						$("#selectprovince").append(province);
					}else{
						
					}
				},error:function(data){
					
				}
			});
			$("#selectprovince").change(function(){
				var provinceid=$(this).val();
				$.ajax({
					type : "POST",
					url : "<?=TOOLURL;?>ajax.php",
					data : {"action":"postcode","operation":"querycity"},
					dataType : 'json',
					success : function(data) {
						if(data.msg=="success"){
							var city='';
							for(var i=0;i<data.result.length;i++){
								if(data.result[i].id!=provinceid){continue;}
								for(var j=0;j<data.result[i].city.length;j++){
									city+='<option value="'+data.result[i].city[j].id+'">'+data.result[i].city[j].city+'</option>';
								}
							}
							if(city!=''){
								$("#selectcity").html(city);
							}else{
								$("#selectcity").html('<option value="">城市</option>');
							}
						}else{
							
						}
					},error:function(data){
						
					}
				});
			});
			$("#postcodeForm").submit(function(){
				if($("#postcode").val()==""){
					alert("需要输入邮编");
					return false;
				}
				$.ajax({
					type : "POST",
					url : "<?=TOOLURL;?>ajax.php",
					data : {"action":"postcode","operation":"queryaddress","postcode":$("#postcode").val()},
					dataType : 'json',
					success : function(data) {
						if(data.msg=="success"){
							$("#address").html(data.result.address.join('，'));
							$("#city").html(data.result.city);
							$("#district").html(data.result.district);
							$("#postNumber").html(data.result.postNumber);
							$("#province").html(data.result.province);
							$("#querypostcoderesult").css("display","block");
						}else{
							
						}
					},error:function(data){
						
					}
				});
				return false;
			});
		});
	</script>
	<script src="//cdnjs.loli.net/ajax/libs/mdui/0.4.2/js/mdui.min.js"></script>
</body>
</html>