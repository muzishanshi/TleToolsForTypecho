<?php
$action = isset($_POST['action']) ? addslashes(trim($_POST['action'])) : '';
if($action=="postcode"){
	$operation = isset($_POST['operation']) ? addslashes(trim($_POST['operation'])) : '';
	$postcode = isset($_POST['postcode']) ? addslashes(trim($_POST['postcode'])) : '';
	$pid = isset($_POST['pid']) ? addslashes(trim($_POST['pid'])) : '';
	$cid = isset($_POST['cid']) ? addslashes(trim($_POST['cid'])) : '';
	$res=file_get_contents("https://tongleer.com/api/web/?action=postcode&operation=".$operation."&code=".$postcode."&pid=".$pid."&cid=".$cid);
	echo($res);
}
?>