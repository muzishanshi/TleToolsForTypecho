<?php
/**
 * @title html转js
 * @subtitle html和js互相转换
 * @package html2js
 * @description 可以在html、js之间相互转换的工具
 * @author 二呆
 * @author email diamond@tongleer.com
 * @author qq 2293338477
 * @author info 一个好人
 * @link http://www.tongleer.com
 * @version 1.0.1
 * @picture https://ws3.sinaimg.cn/large/ecabade5ly1fy7ut7d5egj20e80e8dft.jpg
*/
?>
<html>
<head>
	<meta charset="UTF-8">
	<title>html转js - html和js互相转换</title>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
	<meta name="format-detection" content="telephone=no">
	<meta name="renderer" content="webkit">
	<meta http-equiv="Cache-Control" content="no-siteapp"/>
	<meta name="author" content="二呆">
	<link rel="stylesheet" href="//cdnjs.loli.net/ajax/libs/mdui/0.4.2/css/mdui.min.css">
	<link rel="alternate icon" href="https://ws3.sinaimg.cn/large/ecabade5ly1fxtqvq1t0lj200s00s744.jpg" type="image/png" />
	<script src="https://libs.baidu.com/jquery/1.11.1/jquery.min.js"></script>
</head>
<body class="mdui-theme-primary-indigo mdui-theme-accent-pink">
	<div class="single single-post postid- single-format-standard nav_fixed">
		<section>
			<div class="mdui-table-fluid">
				<table class="mdui-table" style="background-color:#eee;">
				  <tbody>
					<tr>
					  <td>
						<div class="mdui-card postDiv mdui-center mdui-hoverable">
							<div class="mdui-tab mdui-tab-full-width" mdui-tab>
							  <a href="#textdiv" class="mdui-ripple">html转js</a>
							</div>
							<div id="textdiv" class="mdui-col mdui-m-t-1">
								<div class="mdui-textfield mdui-textfield-floating-label">
								  <textarea id="input_content_html2js" onfocus="html2js()"  onkeyup="html2js()" class="mdui-textfield-input"></textarea>
								</div>
								<div class="mdui-textfield mdui-textfield-floating-label">
								  <textarea id="output_content_html2js" onfocus="this.select()" class="mdui-textfield-input"></textarea>
								</div>
							</div>
						</div>
					  </td>
					</tr>
				  </tbody>
				</table>
			</div>
		</section>
	</div>
	<script>
	/*html 转换成 js*/
	function html2js(){
		document.getElementById('output_content_html2js').value="document.writeln(\""+document.getElementById('input_content_html2js').value.replace(/\\/g,"\\\\").replace(/\\/g,"\\/").replace(/\'/g,"\\\'").replace(/\"/g,"\\\"").split('\n').join("\");\ndocument.writeln(\"")+"\");"
	}
	</script>
	<script src="//cdnjs.loli.net/ajax/libs/mdui/0.4.2/js/mdui.min.js"></script>
	<?php include TOOLINCLUDE."footer.php";?>
</body>
</html>