<?php
$action = isset($_POST['action']) ? addslashes(trim($_POST['action'])) : '';
if($action=="phone"){
	$phone = isset($_POST['phone']) ? addslashes(trim($_POST['phone'])) : '';
	$res=file_get_contents("https://tongleer.com/api/web/?action=phone&phone=".$phone);
	echo($res);
}
?>