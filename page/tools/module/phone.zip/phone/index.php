<?php
/**
 * @title 手机号查询
 * @subtitle 一眼辨识归属地
 * @package phone
 * @description 仅支持国内的手机号码查询，具体城市可根据支持的城市列表API来查询。可以通过城市名称进行查询。
 * @author 二呆
 * @author email diamond@tongleer.com
 * @author qq 2293338477
 * @author info 一个好人
 * @link http://www.tongleer.com
 * @version 1.0.1
 * @picture https://ws3.sinaimg.cn/large/ecabade5ly1fy5glh527zj2028028gle.jpg
*/
?>
<html>
<head>
	<meta charset="UTF-8">
	<title>手机号查询 - 一眼辨识归属地</title>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
	<meta name="format-detection" content="telephone=no">
	<meta name="renderer" content="webkit">
	<meta http-equiv="Cache-Control" content="no-siteapp"/>
	<meta name="author" content="二呆">
	<link rel="stylesheet" href="//cdnjs.loli.net/ajax/libs/mdui/0.4.2/css/mdui.min.css">
	<link rel="alternate icon" href="https://ws3.sinaimg.cn/large/ecabade5ly1fxtqvq1t0lj200s00s744.jpg" type="image/png" />
	<script src="https://libs.baidu.com/jquery/1.11.1/jquery.min.js"></script>
</head>
<body class="mdui-theme-primary-indigo mdui-theme-accent-pink">
	<form id="phoneForm" method="get" action="">
		<div class="mdui-textfield">
		  <i class="mdui-icon material-icons">&#xe325;</i>
		  <label class="mdui-textfield-label">手机号</label>
		  <input class="mdui-textfield-input" type="number" id="phone"/>
		  <div class="mdui-textfield-helper">输入手机号，查询归属地。</div>
		</div>
	</form>
	<div id="queryphoneresult" style="display:none;" class="mdui-table-fluid">
	  <table class="mdui-table">
		<thead>
		  <tr>
			<th>城市</th>
			<th>区号</th>
			<th>手机号</th>
			<th>运营商</th>
			<th>省份</th>
			<th>邮编</th>
		  </tr>
		</thead>
		<tbody>
		  <tr>
			<td id="city"></td>
			<td id="cityCode"></td>
			<td id="mobileNumber"></td>
			<td id="operator"></td>
			<td id="province"></td>
			<td id="zipCode"></td>
		  </tr>
		</tbody>
	  </table>
	</div>
	<?php include TOOLINCLUDE."footer.php";?>
	<script>
		$(function(){
			$("#phoneForm").submit(function(){
				if($("#phone").val()==""){
					alert("需要输入手机号");
					return false;
				}
				$.ajax({
					type : "POST",
					url : "<?=TOOLURL;?>ajax.php",
					data : {"action":"phone","phone":$("#phone").val()},
					dataType : 'json',
					success : function(data) {
						if(data.msg=="success"){
							$("#city").html(data.result.city);
							$("#cityCode").html(data.result.cityCode);
							$("#mobileNumber").html(data.result.mobileNumber+"****");
							$("#operator").html(data.result.operator);
							$("#province").html(data.result.province);
							$("#zipCode").html(data.result.zipCode);
							$("#queryphoneresult").css("display","block");
						}else{
							alert("查询失败");
						}
					},error:function(data){
						alert("获取数据错误");
					}
				});
				return false;
			});
		});
	</script>
	<script src="//cdnjs.loli.net/ajax/libs/mdui/0.4.2/js/mdui.min.js"></script>
</body>
</html>