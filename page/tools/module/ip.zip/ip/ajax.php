<?php
$action = isset($_POST['action']) ? addslashes(trim($_POST['action'])) : '';
if($action=="ip"){
	$ip = isset($_POST['ip']) ? addslashes(trim($_POST['ip'])) : '';
	$res=file_get_contents("https://tongleer.com/api/web/?action=ip&ip=".$ip);
	echo($res);
}
?>