<?php
/**
 * @title IP地址
 * @subtitle IP地址随心查
 * @package ip
 * @description 根据IP地址查询对应的省市区信息
 * @author 二呆
 * @author email diamond@tongleer.com
 * @author qq 2293338477
 * @author info 一个好人
 * @link http://www.tongleer.com
 * @version 1.0.1
 * @picture https://ws3.sinaimg.cn/large/ecabade5ly1fy6ki2rf0tj2028028dfm.jpg
*/
?>
<html>
<head>
	<meta charset="UTF-8">
	<title>IP地址 - IP地址随心查</title>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
	<meta name="format-detection" content="telephone=no">
	<meta name="renderer" content="webkit">
	<meta http-equiv="Cache-Control" content="no-siteapp"/>
	<meta name="author" content="二呆">
	<link rel="stylesheet" href="//cdnjs.loli.net/ajax/libs/mdui/0.4.2/css/mdui.min.css">
	<link rel="alternate icon" href="https://ws3.sinaimg.cn/large/ecabade5ly1fxtqvq1t0lj200s00s744.jpg" type="image/png" />
	<script src="https://libs.baidu.com/jquery/1.11.1/jquery.min.js"></script>
</head>
<body class="mdui-theme-primary-indigo mdui-theme-accent-pink">
	<form id="ipForm" method="get" action="">
		<div class="mdui-textfield">
		  <i class="mdui-icon material-icons">&#xe2bd;</i>
		  <label class="mdui-textfield-label">IP地址</label>
		  <input class="mdui-textfield-input" type="text" id="ip"/>
		  <div class="mdui-textfield-helper">输入IP地址，查询省市区信息。</div>
		</div>
	</form>
	<div id="queryipresult" style="display:none;" class="mdui-table-fluid">
	  <table class="mdui-table">
		<thead>
		  <tr>
			<th>城市</th>
			<th>国家</th>
			<th>IP</th>
			<th>省份</th>
		  </tr>
		</thead>
		<tbody>
		  <tr>
			<td id="city"></td>
			<td id="country"></td>
			<td id="ipaddress"></td>
			<td id="province"></td>
		  </tr>
		</tbody>
	  </table>
	</div>
	<?php include TOOLINCLUDE."footer.php";?>
	<script>
		$(function(){
			$("#ipForm").submit(function(){
				if($("#ip").val()==""){
					alert("需要输入IP地址");
					return false;
				}
				$.ajax({
					type : "POST",
					url : "<?=TOOLURL;?>ajax.php",
					data : {"action":"ip","ip":$("#ip").val()},
					dataType : 'json',
					success : function(data) {
						if(data.msg=="success"){
							$("#city").html(data.result.city);
							$("#country").html(data.result.country);
							$("#ipaddress").html(data.result.ip);
							$("#province").html(data.result.province);
							$("#queryipresult").css("display","block");
						}else{
							alert("查询IP失败");
						}
					},error:function(data){
						alert("获取数据错误");
					}
				});
				return false;
			});
		});
	</script>
	<script src="//cdnjs.loli.net/ajax/libs/mdui/0.4.2/js/mdui.min.js"></script>
</body>
</html>