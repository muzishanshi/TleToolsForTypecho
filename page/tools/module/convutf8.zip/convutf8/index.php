<?php
/**
 * @title UTF8转中文
 * @subtitle UTF8和中文互相转换
 * @package convutf8
 * @description 可以在UTF8、中文之间相互转换的工具
 * @author 二呆
 * @author email diamond@tongleer.com
 * @author qq 2293338477
 * @author info 一个好人
 * @link http://www.tongleer.com
 * @version 1.0.1
 * @picture https://ws3.sinaimg.cn/large/ecabade5ly1fy7uldjre9j20e80e8wf5.jpg
*/
?>
<html>
<head>
	<meta charset="UTF-8">
	<title>UTF8转中文 - UTF8和中文互相转换</title>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
	<meta name="format-detection" content="telephone=no">
	<meta name="renderer" content="webkit">
	<meta http-equiv="Cache-Control" content="no-siteapp"/>
	<meta name="author" content="二呆">
	<link rel="stylesheet" href="//cdnjs.loli.net/ajax/libs/mdui/0.4.2/css/mdui.min.css">
	<link rel="alternate icon" href="https://ws3.sinaimg.cn/large/ecabade5ly1fxtqvq1t0lj200s00s744.jpg" type="image/png" />
	<script src="https://libs.baidu.com/jquery/1.11.1/jquery.min.js"></script>
</head>
<body class="mdui-theme-primary-indigo mdui-theme-accent-pink">
	<div class="single single-post postid- single-format-standard nav_fixed">
		<section>
			<div class="mdui-table-fluid">
				<table class="mdui-table" style="background-color:#eee;">
				  <tbody>
					<tr>
					  <td>
						<div class="mdui-card postDiv mdui-center mdui-hoverable">
							<div class="mdui-tab mdui-tab-full-width" mdui-tab>
							  <a href="#textdiv" class="mdui-ripple">UTF8转中文</a>
							</div>
							<div id="textdiv" class="mdui-col mdui-m-t-1">
								<div class="mdui-textfield mdui-textfield-floating-label">
								  <label class="mdui-textfield-label">在此输入要操作的字符串</label>
								  <textarea id="input_content_utf8" class="mdui-textfield-input"></textarea>
								  <div class="mdui-textfield-error">不能为空</div>
								</div>
								<button onclick="convUtf8()" class="mdui-btn mdui-btn-raised mdui-ripple mdui-color-theme-accent">中文转换utf-8</button>
								<button onclick="resChinese()" class="mdui-btn mdui-btn-raised mdui-ripple mdui-color-theme-accent">utf-8还原中文</button>
								<p><button onclick="clean_output_utf8()" class="mdui-btn mdui-btn-raised mdui-ripple mdui-color-theme-accent">清空结果</button></p>
								<div class="mdui-textfield mdui-textfield-floating-label">
								  <textarea id="output_content_utf8" onfocus="this.select()" class="mdui-textfield-input"></textarea>
								</div>
							</div>
						</div>
					  </td>
					</tr>
				  </tbody>
				</table>
			</div>
		</section>
	</div>
	<script>
	/*中文转utf-8*/
	function clean_output_utf8(){
		$('#output_content_utf8').val('');
	}
	function convUtf8() {
		var str = $('#input_content_utf8').val().replace(/[^\u0000-\u00FF]/g, function ($0) { return escape($0).replace(/(%u)(\w{4})/gi, "&#x$2;") });
		$('#output_content_utf8').val(str);
	}
	function resChinese() {
		$('#output_content_utf8').val(unescape($('#input_content_utf8').val().replace(/&#x/g, '%u').replace(/;/g, '')));
	}
	</script>
	<script src="//cdnjs.loli.net/ajax/libs/mdui/0.4.2/js/mdui.min.js"></script>
	<?php include TOOLINCLUDE."footer.php";?>
</body>
</html>